<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        	<form action="#" method="post">
        		<div class="form-group">
        			<label for="title">Title</label>
        			<input type="text" class="form-control" id="title" placeholder="Enter a title">
        		</div>
        		<div class="form-group">
        			<label for="content">Content</label>
        			<input type="text" class="form-control" id="content" placeholder="Enter content">
        		</div>

        		<a class="btn btn-primary" type="Submit">Submit</a>
        	</form>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>