@extends('layouts.master')


@section('content')
<div class="row">
        <div class="col-md-12">
            <h1> About me </h1>
            <p></p>
        </div>
    </div>
@endsection
